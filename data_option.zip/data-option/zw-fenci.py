#   tcellsx
from collections import Counter

import jieba
# def test01():
#      sentence = '结巴分词好不好用全看用户。'
#
#      #1.精准模式
#      result = jieba.lcut(sentence,cut_all=False)
#      print('精确模式',result)
#
#      #2.全模式
#      result = jieba.lcut(sentence, cut_all=True)
#      print('全模式',result)
#
#      #2.搜索引擎模式
#      result = jieba.lcut_for_search(sentence)
#      print('搜索引擎模式',result)
#
#
# def test02():
#
#     sentence = '结巴分词好不好用全看用户。'
#
#     #1.使用函数
#     #将’不好用‘变成一个词
#     jieba.add_word('不好用',freq=1) #词频
#     #将‘结巴’变成‘结‘、’巴’
#     jieba.del_word('结巴', freq=1)
#     result = jieba.lcut(sentence, cut_all=False)
#     print('精确模式', result)
#
#     #2.使用自定义词典
#     jieba.load_userdict('customzidian.txt')
#
#
#
# if __name__ == '__main__':
#     test02()
def stopwordslist(filepath):
    stopwords=[line.strip() for line in open(filepath,'r',encoding='utf-8').readlines()]
    # strip() 方法用于移除字符串头尾指定的字符（默认为空格或换行符）或字符序列。
    #readlines()读取所有行并返回列表
    return stopwords

#对句子进行分词
def seg_sentence(sentence):
    sentence_seged=jieba.cut(sentence.strip())
    stopwords=stopwordslist(r"D:\pythonProjectcatalogue\BS1\data-option\hit_stopwords.txt")#这里加载停用词的路径
    outstr=""
    for word in sentence_seged:
        if word not in stopwords:
            if word!='\t':
                outstr+=word
                outstr+=" "
    return outstr

if __name__ == '__main__':
    inputs = open(r"E:\桌面文件\杂\评论数据\京东\comments_data_content.txt", 'r', encoding='utf-8')  # 加载要处理的文件的路径
    outputs = open(r"E:\桌面文件\杂\评论数据\京东\output.txt", 'w', encoding='utf-8')  # 加载处理后的文件路径
    for line in inputs:
        line_seg = seg_sentence(line)  # 这里的返回值是字符串
        if line_seg != '内容':
            outputs.write(line_seg)
    outputs.close()
    inputs.close()

    with open(r"E:\桌面文件\杂\评论数据\京东\output.txt", 'r',encoding='utf-8') as fr: #读入已经去除停用词的文件
        data = jieba.cut(fr.read())
    data = dict(Counter(data))#dict()用于创建一个字典 counter()作用就是在一个数组内，遍历所有元素，将元素出现的次数记下来

    with open(r"E:\桌面文件\杂\评论数据\京东\cipin.txt", 'w',encoding='utf-8') as fw: #读入存储wordcount的文件路径
        for k, v in data.items():
            fw.write('%s,%d\n' % (k, v))





