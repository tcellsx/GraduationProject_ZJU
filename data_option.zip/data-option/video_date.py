#   tcellsx
import pandas as pd
import os

# 创建一个空的 DataFrame 存储所有日期数据
all_dates_df = pd.DataFrame(columns=['Date'])

# 循环遍历所有文本文件
folder_path = 'E:\桌面文件\杂\\bilibili'
for filename in os.listdir(folder_path):
    if filename.endswith('.txt'):
        file_path = os.path.join(folder_path, filename)
        # 使用 read_csv 方法读取文本文件，以逗号分隔，指定列名
        df = pd.read_csv(file_path, header=None, names=['level', 'comment_level', 'author', 'author_id', 'comment', 'comment_id', 'date', 'likes'], sep=',')
        # 提取日期数据
        dates = pd.to_datetime(df['date'], errors='coerce').dt.date
        # 将日期数据添加到所有日期数据的 DataFrame 中
        all_dates_df = all_dates_df.append(pd.DataFrame({'Date': dates}), ignore_index=True)

# 将所有日期数据保存为一个 Excel 文件
output_file_path = 'all_dates.xlsx'
all_dates_df.to_excel(output_file_path, index=False)

print("All dates extracted and saved to", output_file_path)