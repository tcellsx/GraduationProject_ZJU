# 读取评论时间数据
from collections import defaultdict

import os
import django

from django.conf import settings

# 设置 DJANGO_SETTINGS_MODULE 环境变量
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'BS1.settings')

# 调用 settings.configure() 方法来配置 Django 设置
settings.configure(
SECRET_KEY = 'django-insecure-b+lsn2%r(v6(=qqrmgl0daje=n=ca+3xt=d%t$4!(779(93k68',
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.mysql',
                'NAME': 'bs',
                'USER': 'root',
                'PASSWORD': 'srjTXB108598935.',
                'HOST': '127.0.0.1',
                'PORT': '3306',
        }

    }
)

# 现在可以调用 django.setup() 来初始化 Django 了
django.setup()
from appBS01.models import DateOccurrences
class SortedDates:
    def __init__(self, dates):
        self.dates = dates

    def get_sorted_dates(self):
        return sorted(self.dates.items())

    # def print_sorted_dates(self):
    #     sorted_dates = self.get_sorted_dates()
    #     for date, count in sorted_dates:
    #         print(f"日期 {date} 出现次数: {count}")


# 读取评论时间数据
with open('E:\桌面文件\杂\评论数据\\all_time.txt', 'r',encoding='utf-8') as file:
    comment_times_all = file.readlines()

# 初始化一个字典来存储年月日出现的次数
date_counts = defaultdict(int)

# 提取年月日并统计出现次数
for comment_time in comment_times_all:
    # 评论时间的格式为 "评论时间: yyyy-mm-dd hh:mm:ss"，我们只需要提取年月日部分
    date = comment_time.split()[1]
    # 更新对应年月日的出现次数
    date_counts[date] += 1

# 创建 SortedDates 对象
sorted_dates_obj = SortedDates(date_counts)

# 打印排序后的统计结果
for date, count in date_counts.items():
    obj, created = DateOccurrences.objects.get_or_create(date=date)
    # 如果对象是新创建的，则将出现次数字段的值设置为 count
    if created:
        obj.occurrences_all = count
        obj.save()



date_counts.clear()
with open('E:\桌面文件\杂\评论数据\京东\comments_data_creatime.txt', 'r',encoding='utf-8') as file:
    comment_times_jd = file.readlines()

for comment_time in comment_times_jd:
    # 评论时间的格式为 "评论时间: yyyy-mm-dd hh:mm:ss"，我们只需要提取年月日部分
    date = comment_time.split()[1]
    # 更新对应年月日的出现次数
    date_counts[date] += 1

for date, count in date_counts.items():
    obj, created = DateOccurrences.objects.get_or_create(date=date)
    # 如果对象是新创建的，则将出现次数字段的值设置为 count
    if created:
        obj.occurrences_jd = count
        obj.save()


date_counts.clear()
with open('E:\桌面文件\杂\评论数据\苏宁易购\comments_data_creatime.txt', 'r', encoding='utf-8') as file:
    comment_times_snyg = file.readlines()

for comment_time in comment_times_snyg:
    # 评论时间的格式为 "评论时间: yyyy-mm-dd hh:mm:ss"，我们只需要提取年月日部分
    date = comment_time.split()[1]
    # 更新对应年月日的出现次数
    date_counts[date] += 1

for date, count in date_counts.items():
    obj, created = DateOccurrences.objects.get_or_create(date=date)
    # 如果对象是新创建的，则将出现次数字段的值设置为 count
    if created:
        obj.occurrences_snyg = count
        obj.save()


date_counts.clear()
with open('E:\桌面文件\杂\评论数据\淘宝\comment_time.txt', 'r', encoding='utf-8') as file:
    comment_times_tb = file.readlines()

for comment_time in comment_times_tb:
    # 评论时间的格式为 "评论时间: yyyy-mm-dd hh:mm:ss"，我们只需要提取年月日部分
    date = comment_time.split()[1]
    # 更新对应年月日的出现次数
    date_counts[date] += 1

for date, count in date_counts.items():
    obj, created = DateOccurrences.objects.get_or_create(date=date)
    # 如果对象是新创建的，则将出现次数字段的值设置为 count
    if created:
        obj.occurrences_tb = count
        obj.save()


date_counts.clear()
with open('E:\桌面文件\杂\评论数据\唯品会\comments_data_creatime.txt', 'r', encoding='utf-8') as file:
    comment_times_wph = file.readlines()

for comment_time in comment_times_wph:
    # 评论时间的格式为 "评论时间: yyyy-mm-dd hh:mm:ss"，我们只需要提取年月日部分
    date = comment_time.split()[1]
    # 更新对应年月日的出现次数
    date_counts[date] += 1

for date, count in date_counts.items():
    obj, created = DateOccurrences.objects.get_or_create(date=date)
    # 如果对象是新创建的，则将出现次数字段的值设置为 count
    if created:
        obj.occurrences_wph = count
        obj.save()