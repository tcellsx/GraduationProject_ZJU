#   tcellsx
from openpyxl import load_workbook

# 加载 Excel 文件
workbook = load_workbook('E:\桌面文件\杂\\bilibili\\all.xlsx')

# 选择要操作的工作表
sheet = workbook.active

# 遍历每个单元格，查找并删除目标字符串
for row in sheet.iter_rows():
    for cell in row:
        if isinstance(cell.value, str) and '回复 @' in cell.value:
            # 删除目标字符串及其之前的内容
            cell.value = cell.value.split(':', 1)[-1].strip()

# 保存修改后的 Excel 文件
workbook.save('your_modified_file.xlsx')
