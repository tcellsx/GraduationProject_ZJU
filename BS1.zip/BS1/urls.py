"""BS1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
### url和python函数的对应关系
## 常常操作 常修改

from django.contrib import admin
from django.contrib.auth.decorators import login_required
from django.urls import  re_path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import RedirectView

from appBS01 import views
from appBS01.views import CustomObtainAuthToken, CustomUserRegister, CustomUserHome, ChangeName, verify_password, \
    change_password, change_email, change_name, apply_enterprise, upload_avatar

# from appBS01.views import import_comments
# from appBS01.views import update_sorted_dates

### url与视图函数的对应关系
urlpatterns = [
# 将根路径重定向到 Django admin 登录页面
    path('', login_required(RedirectView.as_view(url='/admin/login/'))),
    path('admin/', admin.site.urls),

    path('geV/userinfo/',views.UserinfoView.as_view()),
    re_path('geV/userinfo/(?P<pk>\d+)/',views.UserinfoView.as_view()),

    path('geV/commenttimeinfo/',views.CreattimeallinfoView.as_view()),
    path('geV/commenttimeinfode/',views.CreattimeallinfoView_de.as_view()),
    path('geV/commentPiechartall/',views.commentPiechartall.as_view()),
    path('geV/positiveWord/', views.positiveWord.as_view()),
    path('geV/negativeWord/', views.negativeWord.as_view()),
    path('geV/posCountAndScore/', views.posCountandScore.as_view()),
    path('geV/negCountAndScore/', views.negCountandScore.as_view()),
    path('geV/posContentAndScore/', views.posContentandScore.as_view()),
    path('geV/negContentAndScore/', views.negContentandScore.as_view()),
    path('geV/productLocation/', views.productLocation.as_view()),
    path('geV/videoPositiveWordCount_sun/', views.videoPositiveWordCount_sun.as_view()),
    path('geV/videoNegitiveWordCount_sun/', views.videoNegitiveWordCount_sun.as_view()),


    path('geV/getData_posContentAndScore_tree/', views.getData_posContentAndScore_tree.as_view()),
    path('geV/getData_negContentAndScore_tree/', views.getData_negContentAndScore_tree.as_view()),
    path('geV/getData_videouperWordCount_tree/', views.getData_videouperWordCount_tree.as_view()),
    path('geV/getData_videoWordCount_tree/', views.getData_videoWordCount_tree.as_view()),

    path('geV/posContentAndScore_Distribution/', views.posContentAndScore_Distribution.as_view()),
    path('geV/negContentAndScore_Distribution/', views.negContentAndScore_Distribution.as_view()),
    path('geV/UperContentAndScore_Distribution/', views.UperContentAndScore_Distribution.as_view()),

    path('geV/ProductWordAndCount/', views.ProductWordAndCount.as_view()),
    path('geV/ProductCountAndScore/', views.ProductCountAndScore.as_view()),
    path('geV/VideoPiechartall/', views.VideoPiechartall.as_view()),
    path('geV/VideoCountAndScore/', views.VideoCountAndScore.as_view()),

    path('api/login/', CustomObtainAuthToken.as_view(), name='login'),
    path('api/register/', CustomUserRegister.as_view(), name='register'),
    path('api/user_home/', CustomUserHome.as_view(), name='user_home'),


    path('api/changename/', ChangeName.as_view(), name='changename'),
    path('api/verify_password/', verify_password.as_view(), name='verify_password'),
    path('api/change_password/', change_password.as_view(), name='change_password'),
    path('api/change_email/', change_email.as_view(), name='change_email'),
    path('api/change_name/', change_name.as_view(), name='change_name'),
    path('api/apply_enterprise/', apply_enterprise.as_view(), name='apply_enterprise'),
    path('api/upload_avatar/', upload_avatar.as_view(), name='upload_avatar'),

    # path('import_comments/', import_comments, name='import_comments'),
    # path('update_sorted_dates/', update_sorted_dates, name='update_sorted_dates'),


    ### www.xxx.com/index/ （访问）->（执行） 后面的函数(views.index)
    ### index写完后可以尝试启动（如何启动看说明()?）
    # path('index/', views.index),

    # path('users/lists/', views.user_list),
    # path('users/add/', views.user_add),
    # path('users/delete/', views.user_delete),

    # path('home/', views.home),

# ### 教学内容：
#     path('tp/', views.tp),
#     path('news/', views.news),
#     path('something/',views.something)


### 用户登录
    # path('login/', views.login),





] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
