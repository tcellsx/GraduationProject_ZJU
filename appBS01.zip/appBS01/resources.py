#   tcellsx
from import_export import resources
from .models import Videosentence

class VideosentenceResource(resources.ModelResource):
    class Meta:
        model = Videosentence
        fields = ('content',  'content_time', 'upers')
