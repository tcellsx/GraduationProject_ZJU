### 不动
from django.apps import AppConfig


class Appbs01Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appBS01'
    verbose_name='Graduation_Design'

    verbose_name='Graduation_Design'
    ## 修改系统中显示的app名称
