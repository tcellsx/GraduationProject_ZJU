### 重要函数
### https://zhuanlan.zhihu.com/p/372185998 美化
### https://newpanjing.github.io/simpleui_docs/config.html
import django.shortcuts
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from django.shortcuts import render,HttpResponse,redirect
from rest_framework import serializers
from rest_framework.authentication import TokenAuthentication

from rest_framework.generics import GenericAPIView
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response
from django.db.models import Q
from rest_framework.views import APIView
from rest_framework_jwt.settings import api_settings

from appBS01.models import Userinfo, DateOccurrences, Productsentence, Productword, ProductPositiveWordCount, \
    ProductNegativeWordCount, ProductLocationCount, PosUperVideoword, NegUperVideoword, videoPositiveWordCount, \
    videoNegativeWordCount, VideoWordCount, UperVideoword, ProductWordCount, Videosentence
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

import os
import re
import unicodedata
# from .models import SortedDates


# Create your views here.

# def index(request):
#     return HttpResponse("欢迎使用")

#序列化集，一个模型对应一个序列化集
class UserinfoSerialzer(serializers.ModelSerializer):
    class Meta:
        model = Userinfo
        fields = ['name', 'user_id', 'account', 'age']

class UserinfoView(GenericAPIView):
    queryset = Userinfo.objects.all()
    serializer_class = UserinfoSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

#热力图
class CreattimeallinfoSerialzer(serializers.ModelSerializer):
    class Meta:
        model = DateOccurrences
        fields = ['occurrences_all']

class CreattimeallinfoView(GenericAPIView):
    queryset = DateOccurrences.objects.all()
    serializer_class = CreattimeallinfoSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

#折线图,柱图
class CreattimeallinfoSerialzer_de(serializers.ModelSerializer):
    class Meta:
        model = DateOccurrences
        fields = ['date','occurrences_all','occurrences_jd','occurrences_wph','occurrences_tb','occurrences_snyg']

class CreattimeallinfoView_de(GenericAPIView):
    queryset = DateOccurrences.objects.all()
    serializer_class = CreattimeallinfoSerialzer_de
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class commentPiechartallSerialzer(serializers.ModelSerializer):
    class Meta:
        model = Productsentence
        fields = ['is_positive']

class commentPiechartall(GenericAPIView):
    queryset = Productsentence.objects.all()
    serializer_class = commentPiechartallSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class VideoPiechartallSerialzer(serializers.ModelSerializer):
    class Meta:
        model = Videosentence
        fields = ['is_positive']

class VideoPiechartall(GenericAPIView):
    queryset = Videosentence.objects.all()
    serializer_class = VideoPiechartallSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)



class positiveWordSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductPositiveWordCount
        fields = ['word','count','score']

class positiveWord(GenericAPIView):
    queryset = ProductPositiveWordCount.objects.all()
    serializer_class = positiveWordSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class negativeWordSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductNegativeWordCount
        fields = ['word','count','score']

class negativeWord(GenericAPIView):
    queryset = ProductNegativeWordCount.objects.all()
    serializer_class = negativeWordSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class posCountandScoreSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductPositiveWordCount
        fields = ['count','score']

class posCountandScore(GenericAPIView):
    queryset = ProductPositiveWordCount.objects.all()
    serializer_class = posCountandScoreSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class negCountandScoreSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductNegativeWordCount
        fields = ['count','score']

class negCountandScore(GenericAPIView):
    queryset = ProductNegativeWordCount.objects.all()
    serializer_class = negCountandScoreSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class posContentandScoreSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductPositiveWordCount
        fields = ['word','score']

class posContentandScore(GenericAPIView):
    queryset = ProductPositiveWordCount.objects.all()
    serializer_class = posContentandScoreSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class negContentandScoreSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductNegativeWordCount
        fields = ['word','score']

class negContentandScore(GenericAPIView):
    queryset = ProductNegativeWordCount.objects.all()
    serializer_class = negContentandScoreSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class productLocationSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductLocationCount
        fields = ['location','count']

class productLocation(GenericAPIView):
    queryset = ProductLocationCount.objects.all()
    serializer_class = productLocationSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class videoPositiveWordCount_sunSerialzer(serializers.ModelSerializer):
    class Meta:
        model = PosUperVideoword
        fields = ['word','count','content_uper']

class videoPositiveWordCount_sun(GenericAPIView):
    queryset = PosUperVideoword.objects.all()
    serializer_class = videoPositiveWordCount_sunSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(score__gt=0.55)
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class videoNegitiveWordCount_sunSerialzer(serializers.ModelSerializer):
    class Meta:
        model = NegUperVideoword
        fields = ['word','count','content_uper']

class videoNegitiveWordCount_sun(GenericAPIView):
    queryset = NegUperVideoword.objects.all()
    serializer_class = videoNegitiveWordCount_sunSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(score__lt=0.45)
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)



class getData_posContentAndScore_treeSerialzer(serializers.ModelSerializer):
    class Meta:
        model = videoPositiveWordCount
        fields = ['word','count','score']

class getData_posContentAndScore_tree(GenericAPIView):
    queryset = videoPositiveWordCount.objects.all()
    serializer_class = getData_posContentAndScore_treeSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(score__gt=0.55)
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class getData_negContentAndScore_treeSerialzer(serializers.ModelSerializer):
    class Meta:
        model = videoNegativeWordCount
        fields = ['word','count','score']

class getData_negContentAndScore_tree(GenericAPIView):
    queryset = videoNegativeWordCount.objects.all()
    serializer_class = getData_negContentAndScore_treeSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(score__lt=0.45)
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class getData_videoWordCount_treeSerialzer(serializers.ModelSerializer):
    class Meta:
        model = VideoWordCount
        fields = ['word','count']

class getData_videoWordCount_tree(GenericAPIView):
    queryset = VideoWordCount.objects.all()
    serializer_class = getData_videoWordCount_treeSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(Q(score__lt=0.45) | Q(score__gt=0.55))
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class VideoCountAndScoreSerialzer(serializers.ModelSerializer):
    class Meta:
        model = VideoWordCount
        fields = ['count','score']

class VideoCountAndScore(GenericAPIView):
    queryset = VideoWordCount.objects.all()
    serializer_class = VideoCountAndScoreSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(Q(score__lt=0.45) | Q(score__gt=0.55))
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class getData_videouperWordCount_treeSerialzer(serializers.ModelSerializer):
    class Meta:
        model = UperVideoword
        fields = ['word','count','content_uper']

class getData_videouperWordCount_tree(GenericAPIView):
    queryset = UperVideoword.objects.all()
    serializer_class = getData_videouperWordCount_treeSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(Q(score__lt=0.45) | Q(score__gt=0.55))
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class posContentAndScore_DistributionSerialzer(serializers.ModelSerializer):
    class Meta:
        model = videoPositiveWordCount
        fields = ['score','count']

class posContentAndScore_Distribution(GenericAPIView):
    queryset = videoPositiveWordCount.objects.all()
    serializer_class = posContentAndScore_DistributionSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(score__gt=0.55)
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class negContentAndScore_DistributionSerialzer(serializers.ModelSerializer):
    class Meta:
        model = videoNegativeWordCount
        fields = ['score','count']

class negContentAndScore_Distribution(GenericAPIView):
    queryset = videoNegativeWordCount.objects.all()
    serializer_class = negContentAndScore_DistributionSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(score__lt=0.45)
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class UperContentAndScore_DistributionSerialzer(serializers.ModelSerializer):
    class Meta:
        model = UperVideoword
        fields = ['content_uper','score','count']

class UperContentAndScore_Distribution(GenericAPIView):
    queryset = UperVideoword.objects.all()
    serializer_class = UperContentAndScore_DistributionSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(Q(score__lt=0.45) | Q(score__gt=0.55))
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)


class ProductWordAndCountSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductWordCount
        fields = ['word','count']

class ProductWordAndCount(GenericAPIView):
    queryset = ProductWordCount.objects.all()
    serializer_class = ProductWordAndCountSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(Q(score__lt=0.43) | Q(score__gt=0.58))
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)

class ProductCountAndScoreSerialzer(serializers.ModelSerializer):
    class Meta:
        model = ProductWordCount
        fields = ['count','score']

class ProductCountAndScore(GenericAPIView):
    queryset = ProductWordCount.objects.all()
    serializer_class = ProductCountAndScoreSerialzer
    def get(self,request):
        # 只有get表示查询所有
        # 只有post表示增加
        # get+pk 按照某个主键值查
        # put+pk 按照某个主键值改
        # delete+pk 按照某个主键值删
        self.queryset = self.get_queryset().filter(Q(score__lt=0.45) | Q(score__gt=0.55))
        serializer = self.get_serializer(instance=self.get_queryset(),many =True)
        return Response(serializer.data)






class LoginView(APIView):
    def post(self, request):
        account = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=account, password=password)
        if user:
            # 如果验证通过，生成令牌
            jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
            jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
            payload = jwt_payload_handler(user)
            token = jwt_encode_handler(payload)
            return Response({'token': token})
        else:
            # 如果验证失败，返回错误消息
            return Response({'error': 'Invalid credentials'}, status=400)


# views.py

from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.response import Response
from rest_framework_jwt.settings import api_settings
from rest_framework.authtoken.models import Token
from .models import FrontendUser
from django.utils import timezone

class CustomObtainAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        last_login_before = user.last_login

        user.last_login = timezone.now()
        user.save()

        token, _ = Token.objects.get_or_create(user=user)

        # 根据 user 获取前端用户信息
        frontend_user = FrontendUser.objects.get(user=user)

        # 生成 JWT token
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = jwt_payload_handler(user)
        jwt_token = jwt_encode_handler(payload)

        return Response({
            'token': jwt_token,
            'is_advanced': frontend_user.is_advanced,
            'registration_date': user.date_joined,
            'last_login': last_login_before
        })


from rest_framework.views import APIView
from django.db import IntegrityError
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework import status
from django.core.exceptions import ValidationError

class CustomUserRegister(APIView):
    permission_classes = [AllowAny]  # 允许任何用户访问注册接口

    def post(self, request, *args, **kwargs):
        # 从请求中获取注册信息
        username = request.data.get('username')
        password = request.data.get('password')

        # 检查密码的复杂性
        try:
            validate_password(password)
        except ValidationError as e:
            # 返回密码复杂性错误消息
            return Response({'error': e.messages}, status=status.HTTP_400_BAD_REQUEST)


        # 创建新用户并保存到数据库
        try:
            user = User.objects.create_user(username=username, password=password)
            user.save()

            # 创建前端用户信息
            frontend_user = FrontendUser.objects.create(user=user)

            # 返回注册成功信息
            return Response({'message': 'Account created successfully!'}, status=status.HTTP_201_CREATED)
        except IntegrityError:
            return Response({'error': 'Username already exists!'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': 'Undefined Error! Try Again!'}, status=status.HTTP_400_BAD_REQUEST)


import jwt
from django.conf import settings
from django.contrib.auth.models import User
from rest_framework.exceptions import AuthenticationFailed

def get_user_from_token(token):
    try:
        # 解码 token 获取 payload
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])
        # 从 payload 中提取用户名
        username = payload['username']
        # 根据用户名获取用户对象
        user = User.objects.get(username=username)
        return user
    except jwt.ExpiredSignatureError:
        raise AuthenticationFailed('Token已过期，请重新登录')
    except jwt.InvalidTokenError:
        raise AuthenticationFailed('无效的Token，请重新登录')
    except User.DoesNotExist:
        raise AuthenticationFailed('用户不存在')


import base64
class CustomUserHome(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        token = request.data.get('token')
        if token:
            try:
                # 使用 token 获取用户对象
                user = get_user_from_token(token)

                # 获取用户的前端用户对象
                frontend_user = FrontendUser.objects.get(user=user)

                if frontend_user.have_Avatar:
                    # 读取用户头像图片文件并转换为 Base64 编码字符串
                    avatar_file_path = os.path.join(settings.MEDIA_ROOT, 'avatars', str(user.username),
                                                    frontend_user.avatar_filename)
                    with open(avatar_file_path, 'rb') as img_file:
                        avatar_data = base64.b64encode(img_file.read()).decode('utf-8')
                        # 构建用户信息的字典
                        user_data = {
                            'first_name': user.first_name,
                            'last_name': user.last_name,
                            'email': user.email,
                            'is_advanced': frontend_user.is_advanced,
                            'have_Avatar': frontend_user.have_Avatar,
                            'fileExtension': frontend_user.avatar_extension,
                            'avatar': avatar_data,  # 添加头像图片数据字段
                            'username': user.username,
                            # 可以根据需要添加其他用户信息字段
                        }
                else:
                    user_data = {
                        'first_name': user.first_name,
                        'last_name': user.last_name,
                        'email': user.email,
                        'is_advanced': frontend_user.is_advanced,
                        'have_Avatar': frontend_user.have_Avatar,
                        'fileExtension': frontend_user.avatar_extension,
                        'avatar': None,  # 或者默认的图片数据
                        'username': user.username,
                        # 可以根据需要添加其他用户信息字段
                    }

                return Response(user_data)
            except AuthenticationFailed as e:
                return Response({'error': str(e)}, status=400)
        else:
            return Response({'error': 'Token not provided'}, status=400)



class ChangeName(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        # 从请求中获取原始昵称和修改后的昵称
        original_username = request.data.get('original_username')
        new_username = request.data.get('change_username')

        # 查找用户记录
        try:
            user = User.objects.get(username=original_username)
        except User.DoesNotExist:
            return Response({'message': '用户不存在！'}, status=400)

        # 检查新昵称是否已被占用
        if User.objects.filter(username=new_username).exists():
            return Response({'message': '昵称已被占用,重新输入！'}, status=400)

        # 更新用户的昵称
        user.username = new_username
        frontend_user = FrontendUser.objects.get(user=user)
        user.save()
        frontend_user.user = user
        frontend_user.save()
        token, _ = Token.objects.get_or_create(user=user)

        # 生成 JWT token
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = jwt_payload_handler(user)
        jwt_token = jwt_encode_handler(payload)
        return Response({'message': '昵称修改成功！','token':jwt_token}, status=200)

class verify_password(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        token = request.data.get('token')
        original_password = request.data.get('password')
        user = get_user_from_token(token)

        # 校验密码是否正确
        if user.check_password(original_password):
            return Response({'message': '密码验证成功'}, status=200)
        else:
            return Response({'message': '密码验证失败'}, status=400)

class change_password(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        token = request.data.get('token')
        new_password = request.data.get('new_password')
        user = get_user_from_token(token)  # 或者从请求中获取用户对象的方式

        # 更新用户的密码为新密码
        user.set_password(new_password)
        user.save()

        return Response({'message': '密码修改成功'}, status=200)

class change_email(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        token = request.data.get('token')
        new_email = request.data.get('first_name')
        user = get_user_from_token(token)  # 或者从请求中获取用户对象的方式

        # 更新用户的密码为新密码
        user.email = new_email
        user.save()
        token, _ = Token.objects.get_or_create(user=user)

        # 生成 JWT token
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = jwt_payload_handler(user)
        jwt_token = jwt_encode_handler(payload)

        return Response({'message': '密码修改成功','token':jwt_token}, status=200)


class change_name(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        token = request.data.get('token')
        first_name = request.data.get('first_name')
        last_name = request.data.get('last_name')
        user = get_user_from_token(token)  # 或者从请求中获取用户对象的方式

        # 更新用户的密码为新密码
        user.first_name = first_name
        user.last_name = last_name
        user.save()
        token, _ = Token.objects.get_or_create(user=user)

        # 生成 JWT token
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = jwt_payload_handler(user)
        jwt_token = jwt_encode_handler(payload)

        return Response({'message': '姓名修改成功','token':jwt_token}, status=200)


from rest_framework.views import APIView
from rest_framework.response import Response
from .models import ActivationCode


class apply_enterprise(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        activation_code = request.data.get('activationCode')
        token = request.data.get('token')
        user = get_user_from_token(token)  # 或者从请求中获取用户对象的方式
        frontend_user = FrontendUser.objects.get(user=user)
        # 检查激活码是否存在并且可用次数大于0
        try:
            code = ActivationCode.objects.get(code=activation_code)
            if code.uses_remaining > 0:
                # 更新激活码的使用次数
                code.uses_remaining -= 1
                code.save()

                # 在此处更新用户权限为企业用户
                # 例如，更新用户的 is_advanced 字段为 True
                frontend_user.is_advanced = True
                token, _ = Token.objects.get_or_create(user=user)
                frontend_user.save()

                # 生成 JWT token
                jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
                jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
                payload = jwt_payload_handler(user)
                jwt_token = jwt_encode_handler(payload)

                return Response({'message': '申请成功','token':jwt_token}, status=200)
            else:
                return Response({'message': '激活码已用尽，请使用其他激活码'}, status=400)
        except ActivationCode.DoesNotExist:
            return Response({'message': '激活码不存在'}, status=400)

from rest_framework.parsers import MultiPartParser

class upload_avatar(APIView):
    permission_classes = [MultiPartParser]
    permission_classes = [AllowAny]  # 需要认证的用户才能上传头像

    def post(self, request, *args, **kwargs):
        avatar_file = request.FILES.get('avatar')
        print(request.data)
        token = request.data.get('token')
        user = get_user_from_token(token)  # 或者从请求中获取用户对象的方式
        frontend_user = FrontendUser.objects.get(user=user)

        if user.is_authenticated:
            filename, extension = os.path.splitext(avatar_file.name)
            frontend_user.avatar_extension = extension.lstrip('.')
            # 构建文件保存路径，假设存在 MEDIA_ROOT/settings.MEDIA_URL 中
            user_folder = os.path.join(settings.MEDIA_ROOT, 'avatars', str(user.username))
            os.makedirs(user_folder, exist_ok=True)  # 创建用户文件夹
            filename = f"{user.username}Avatar.{avatar_file.name.split('.')[-1]}"  # 生成新文件名
            filepath = os.path.join(user_folder, filename)  # 构建文件路径

            # 将文件保存到指定路径
            with open(filepath, 'wb') as f:
                for chunk in avatar_file.chunks():
                    f.write(chunk)

            frontend_user.have_Avatar = True
            frontend_user.avatar_filename = filename
            frontend_user.save()
            token, _ = Token.objects.get_or_create(user=user)
            jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
            jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
            payload = jwt_payload_handler(user)
            jwt_token = jwt_encode_handler(payload)
            # 返回成功信息
            return Response({'message': '头像上传成功', 'filename': filename,'token':jwt_token},status=200)
        else:
            return Response({'message': '用户未认证'}, status=401)




# class ProductwordinfoSerialzer(serializers.ModelSerializer):
#     class Meta:
#         model = Productword
#         fields = ['word','content_id','pos','is_positive']
#
# class Productwordinfo(GenericAPIView):
#     queryset = Productword.objects.all()
#     serializer_class = ProductwordinfoSerialzer
#     def get(self,request):
#         # 只有get表示查询所有
#         # 只有post表示增加
#         # get+pk 按照某个主键值查
#         # put+pk 按照某个主键值改
#         # delete+pk 按照某个主键值删
#         serializer = self.get_serializer(instance=self.get_queryset(),many =True)
#         return Response(serializer.data)

# ##导入评论数据部分
# # 定义一个函数来过滤表情符号
# def remove_emoji(text):
#     emoji_pattern = re.compile("["
#                                u"\U0001F600-\U0001F64F"  # emoticons
#                                u"\U0001F300-\U0001F5FF"  # symbols & pictographs
#                                u"\U0001F680-\U0001F6FF"  # transport & map symbols
#                                u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
#                                u"\U00002500-\U00002BEF"  # chinese char
#                                u"\U00002702-\U000027B0"
#                                u"\U00002702-\U000027B0"
#                                u"\U000024C2-\U0001F251"
#                                u"\U0001f926-\U0001f937"
#                                u"\U00010000-\U0010ffff"
#                                u"\u2640-\u2642"
#                                u"\u2600-\u2B55"
#                                u"\u200d"
#                                u"\u23cf"
#                                u"\u23e9"
#                                u"\u231a"
#                                u"\ufe0f"  # dingbats
#                                u"\u3030"
#                                "]+", flags=re.UNICODE)
#     return emoji_pattern.sub(r'', text)
#
#
# def import_comments(request):
#     # 评论数据存放目录
#     data_dir = "E:\\桌面文件\\杂\\评论数据\\"
#     channels = ['jd', 'snyg', 'wph', 'tb']
#
#     for channel in channels:
#         # 评论内容文件路径
#         content_file_path = os.path.join(data_dir, f"{channel}\\comments_data_content.txt")
#         # 评论时间文件路径
#         time_file_path = os.path.join(data_dir, f"{channel}\\comments_data_creatime.txt")
#         # 评论地区文件路径
#         location_file_path = os.path.join(data_dir, f"{channel}\\comments_data_location.txt")
#
#         # 打开评论内容文件
#         with open(content_file_path, 'r', encoding='utf-8') as content_file:
#             # 一次性读取整个文件内容
#             content_data = content_file.read()
#
#             # 使用正则表达式将内容拆分为多个评论
#             comment_contents = content_data.split('评论内容:')[1:]  # 从第二个 '评论内容:' 开始切片，忽略第一个空评论
#
#             # 打开评论时间文件
#             with open(time_file_path, 'r', encoding='utf-8') as time_file:
#                 # 打开评论地区文件
#                 with open(location_file_path, 'r', encoding='utf-8') as location_file:
#                     # 逐个处理评论数据
#                     for content, time_line, location_line in zip(comment_contents, time_file, location_file):
#                         # 提取评论内容并删除特殊字符和表情符号
#                         content = content.strip().replace('\n', '')
#                         # content = content.encode('ascii', 'ignore').decode('utf-8')
#                         # content = re.sub(r'[^\x00-\x7F]+', '', content)
#                         # content = re.sub(r'[^\w\s]', '', content)
#                         content = re.sub(r'[^\w\s\u4e00-\u9fa5]', '', content)
#                         print(content)
#
#                         # 提取评论时间中的日期部分
#                         time = time_line.strip().split()[1][:10]
#
#                         # 提取评论地区
#                         location = location_line.strip()
#
#                         # 检查当前 channel 是否存在于 channels 列表中，如果不存在则跳过
#                         if channel not in channels:
#                             continue
#
#                         # 创建评论对象并保存到数据库
#                         Productsentence.objects.create(
#                             content=content.strip(),
#                             content_time=time,
#                             content_location=location.strip()
#                         )
#
#     return HttpResponse("评论数据导入成功！")



### 时间数据排序操作
# @csrf_exempt  # 这是一个简单的 CSRF 保护豁免，因为我们不处理任何敏感数据
# def update_sorted_dates(request):
#     if request.method == "GET":
#         # 调用 SortedDates 类的 update_sorted_dates 方法
#         SortedDates.update_sorted_dates()
#         return JsonResponse({"message": "Sorted dates updated successfully."})
#     else:
#         return JsonResponse({"error": "Invalid request method."}, status=405)
# def user_list(request):
#
#     ### 默认情况下是在app的目录下写html（创建一个templates文件夹，写在里面）
#     ### 逻辑是根据qpp的注册顺序，逐一去他们的templates的目录中找
#
#     # 1.获取数据库中所有用户信息
#     ## [对象，对象，对象]
#     data_list = Userinfo.objects.all()
#     return render(request , "user_list.html",{"data_list":data_list})
#
#
#



# def user_add(request):
#     ### 1.GET，看到页面，输入内容
#     ### 2.POST，提交——>写入数据库
#     if request.method == "GET":
#         return render(request, "user_add.html")
#
#     ### 获取用户提交的数据
#     name = request.POST.get("name")
#     account = request.POST.get("account")
#     pwd = request.POST.get("pwd")
#     age = request.POST.get("age")
#
#     ### 提交到数据库
#     Userinfo.objects.create(name = name,account = account,password = pwd,age = age)
#
#     # return  HttpResponse("添加成功")
#     ### 自动跳转
#     # return redirect("http://127.0.0.1:8000/users/lists/")
#     return redirect("/users/lists/")
#
#
# def user_delete(request):
#     nid = request.GET.get('nid')
#     Userinfo.objects.filter(id=nid).delete()
#     return redirect("/users/lists/")
#
#
#
#
# def home(request):
#     return render(request, "home.html")
#
# # ### 用于学习Django的模板语句
# # def tp(request):
# #     ### 有语法时用{%  %}，取值时用{{  }}
# #     name = "Tobin"
# #     ### 列表
# #     roles = {"管理眼","老师","CEO"}
# #     ### 字典
# #     user_info = {"name":"Tobin","salary":10000,"role":"CTO"}
# #     ### 列表套字典
# #     data_list1 = [
# #         {"name": "T", "salary": 10000, "role": "CTO"},
# #         {"name": "b", "salary": 1000, "role": "CBO"},
# #         {"name": "n", "salary": 100, "role": "CCO"},
# #     ]
# #
# #     return render(request, "tp.html",{"n1":name, "n2":roles, "n3":user_info, "n4":data_list1})
# #
# # ### 直接通过网络请求获取
# # def news(request):
# #     ### 1.自己定义新闻
# #     ### 2.去数据库取
# #     ### 3.爬虫网络请求取
# #
# #     import requests as reqs
# #     res = reqs.get("https://api.m.jd.com/?appid=item-v3&functionId=pc_club_productPageComments&client=pc&clientVersion=1.0.0&t=1709571830788&loginType=3&uuid=181111935.170957100638087579330.1709571006.1709571006.1709571006.1&productId=100066896214&score=0&sortType=6&page=0&pageSize=10&isShadowSku=0&fold=1&bbtf=&shield=")
# #     data_list2 = res.json()
# #     print(data_list2)
# #     return render(request, "news.html", {"news_list" : data_list2})
#
def something(request):
    return render(request,'something.html')
#     ### request是一个对象，封装了用户发来的所有请求相关数据
#     ### 1.获取用户请求方式
#     print(request.method)
#
#     ### 2.在url上传递参数
#     print(request.GET)
#
#     ### 3.在请求体中提交数据
#     print(request.POST)
#
#     ### 4.将字符串内容返还给响应者
#     return HttpResponse("返回内容")
#
#     ### 5.读取HTMl内容 + 渲染（替换）  -> 字符串，返回给用户浏览器
#     return render(request,'something.html',{"title" : "来了"})
# #
# #     ### 6.[响应]让浏览器重定向
# #     return redirect("https://www.baidu.com")
#
#
# def login(request):
#     if request.method == "GET":
#         return render(request, "login.html")
#     ### else:  ###如果是POST则获取内容,注释掉是因为完全可以优化
#     # print(request.POST)
#     username = request.POST.get("user")
#     password = request.POST.get("pwd")
#     # print(username)
#     # print(password)
#     if username == 'root' and password == '123':
#         # return  HttpResponse("登录成功")
#         return redirect("https://www.baidu.com")
#     ### else:  ### 注释掉是因为完全可以优化
#         # return HttpResponse("登录失败")
#     return render(request, "login.html", {"error_msg": "用户名或密码错误！"})
