### 对数据库操作
import jieba
import string
import jieba.analyse
from django.core.validators import RegexValidator
from django.db import models
from collections import defaultdict
from django.contrib.auth.models import User


# Create your models here.


# ### 数据库操作的类
# class Userinfo(models.Model):
#         name = models.CharField(max_length=32)
#         password = models.CharField(max_length=64)
#         age = models.IntegerField()
#         account = models.IntegerField()
#         #data = models.IntegerField(null = True,blank = True) 允许为空的例子
#         ### 这三行相当于:
#         # create table appBS01_Userinfo(
#         #     id bigint auto_increment primary key,
#         #     name varchar(32),
#         #     password varchar(32),
#         #     age int
#         # )
#
#
#         # 这个类创建好了以后不会立马在MySQL里面出现表，需要两个命令：
#         # python manage.py makemigrations
#         # python manage.py migrate
# ### 创建语句
# ### 本质是：insert into appBS01_Userinfo(name)values("txb")...
# ### 可以写到view.py中
# Userinfo.objects.create(name = "txb",password = "12345",age = 21,account = 18752339198)
#
# ### 删除语句
# Userinfo.objects.filter(id=3).delete()
# Userinfo.objects.all().delete()
#
# ### 获取数据
# data_list = Userinfo.objects.all() ### data_list = [对象，对象，对象] queryset类型
# for obj in data_list:
#         print(obj.name,obj.password,obj.age,obj.account)
#
# data_list = Userinfo.objects.filter(id = 1)  ### 依旧是queryset类型
# row_obj = Userinfo.objects.filter(id = 1).first() ###这个就可以获取到那一行的数据
#
# ### 更新数据
# Userinfo.objects.all().update(password = 999) ### 表内全部更新
# Userinfo.objects.filter(id = 2).update(age = 19)

class Userinfo(models.Model):
    name = models.CharField(max_length=32, verbose_name='Name')
    user_id = models.CharField(max_length=32, verbose_name='User-ID', default='未命名用户')
    account = models.BigIntegerField(max_length=12, verbose_name='Account')
    password = models.CharField(max_length=64, verbose_name='Password')
    age = models.IntegerField(verbose_name='Age')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Created At')
    last_login = models.DateTimeField(null=True, blank=True, verbose_name='Last Login')
    ## verbose_name的作用是增加用户时显示的时Verbose_name的内容
    ## 可以写,help_text='XXX'增加提示
    ### 下拉框的写法
    SEX_CHOICES = ((1, 'MALE'), (2, 'FEMALE'))
    sex = models.IntegerField(choices=SEX_CHOICES, default=1, verbose_name='Gender')

    def __str__(self) -> str:
        return f'{self.name},{self.user_id},{self.account},{self.created_at}'
        ## 让Userinfo.objects 变成大括号里的内容
        ## 模组类字符串化

    class Meta:
        verbose_name_plural = verbose_name = '1.1 Common_Users'
        ## 这句话作用是让Userinfo在界面中显示为’Users‘
        app_label = 'appBS01'


class FrontendUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_advanced = models.BooleanField(default=False)
    have_Avatar = models.BooleanField(default=False)
    last_login = models.DateTimeField(null=True, blank=True, verbose_name='Last Login')
    avatar_filename = models.CharField(max_length=255, blank=True, null=True, verbose_name='Avatar Filename')
    avatar_extension = models.CharField(max_length=10, blank=True, null=True,
                                        verbose_name='Avatar Extension')  # 添加拓展名字段

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = verbose_name = '1.1 Common_Users'
        ## 这句话作用是让Userinfo在界面中显示为’Users‘
        app_label = 'appBS01'

from django.db import models


import random
import string
def generate_random_code(length=30):
    # 从字母和数字中随机选择字符
    characters = string.ascii_letters + string.digits
    # 生成指定长度的随机字符串
    random_code = ''.join(random.choices(characters, k=length))
    return random_code


class ActivationCode(models.Model):
    code = models.CharField(max_length=30, unique=True)
    uses_remaining = models.IntegerField(default=5)

    def delete_zero_counts_and_add_new_code(self):
        # 删除所有次数为0的记录
        ActivationCode.objects.filter(uses_remaining=0).delete()

        # 添加一条新记录
        # 这里假设您已经有一个函数可以生成随机的激活码，您可以替换成您自己的方法
        new_code = generate_random_code()
        ActivationCode.objects.create(code=new_code, uses_remaining=5)

    def __str__(self):
        return self.code

    class Meta:
        verbose_name_plural = verbose_name = '4 Activation_Code'


from snownlp import SnowNLP


class Productsentence(models.Model):
    content = models.TextField(verbose_name='评论内容')
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    is_positive = models.BooleanField(verbose_name='好评', blank=True, null=True)
    content_time = models.DateField(verbose_name='评论时间', blank=True, null=True)
    content_location = models.CharField(max_length=100, verbose_name='评论地区', blank=True, null=True)
    CHANNEL_CHOICES = [
        ('jd', '京东'),
        ('snyg', '苏宁易购'),
        ('wph', '唯品会'),
        ('tb', '淘宝'),
    ]
    channel = models.CharField(max_length=20, verbose_name='评论渠道', choices=CHANNEL_CHOICES, blank=True, null=True)

    def save(self, *args, **kwargs):
        # 使用 SnowNLP 对评论内容进行情感分析并获取评分
        if self.content:
            s = SnowNLP(self.content)
            self.score = s.sentiments
            # 根据评分设置好评或差评的布尔值
            self.is_positive = True if self.score >= 0.5 else False
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Review ID: {self.pk}, Score: {self.score}, Positive: {self.is_positive}, Time: {self.content_time}, Location: {self.content_location}, Channel: {self.channel}"

    class Meta:
        verbose_name_plural = verbose_name = '2 Product_sentence'


class DateOccurrences(models.Model):
    date = models.DateField(unique=True)  # 日期字段，唯一性约束
    occurrences_jd = models.PositiveIntegerField(default=0)  # 出现次数字段，必须是正整数
    occurrences_wph = models.PositiveIntegerField(default=0)  # 出现次数字段，必须是正整数
    occurrences_tb = models.PositiveIntegerField(default=0)  # 出现次数字段，必须是正整数
    occurrences_snyg = models.PositiveIntegerField(default=0)  # 出现次数字段，必须是正整数
    occurrences_all = models.PositiveIntegerField(default=0)  # 出现次数字段，必须是正整数

    #
    # def save(self, *args, **kwargs):
    #     # 计算 occurrences_all 字段的值为前面三项之和
    #     self.occurrences_all = self.occurrences_jd + self.occurrences_wph + self.occurrences_tb + self.occurrences_snyg
    #     super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"日期 {self.date} 出现次数: {self.occurrences_all}"

    class Meta:
        verbose_name_plural = verbose_name = '2.1 Time_data'
        # app_label = 'appBS01'


import jieba.posseg as pseg


class Productword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    content_id = models.IntegerField(verbose_name='所属内容ID')
    pos = models.CharField(max_length=10, verbose_name='词性')
    is_positive = models.BooleanField(verbose_name='好评')

    @classmethod
    def get_last_content_id(cls):
        last_object = cls.objects.last()
        if last_object:
            return last_object.content_id
        else:
            return 0

    @classmethod
    def create_words(cls, sentence):
        # 获取Productword的最后一个对象的content_id
        last_content_id = cls.get_last_content_id()

        # 获取Productsentence的最后一个对象的pk
        last_sentence_pk = Productsentence.objects.last().pk

        # 比较最后一个content_id和最后一个sentence的pk
        if last_content_id < last_sentence_pk:
            # 获取新增的Productsentence对象
            new_sentences = Productsentence.objects.filter(pk__gt=last_content_id + 1)
            for sentence in new_sentences:
                sentence.save()

                # 加载停用词
                stop_words = []
                with open('D:\pythonProjectcatalogue\BS1\data-option\hit_stopwords.txt', 'r', encoding='utf-8') as file:
                    for line in file:
                        stop_words.append(line.strip())

                # 获取标点符号集合
                punctuation_set = set(string.punctuation)

                # 使用jieba对句子进行分词和词性标注
                words = pseg.cut(sentence.content)
                for word, flag in words:
                    # 创建Productword对象
                    product_word = Productword.objects.create(
                        word=word,
                        content_id=sentence.pk,
                        pos=flag,
                        is_positive=sentence.is_positive
                    )
                    productcount_word, created = unsortedProductWordCount.objects.get_or_create(
                        word=word
                    )
                    if not created:
                        productcount_word.count += 1
                        productcount_word.save()

                    # 根据is_positive更新对应的统计模型
                    if sentence.is_positive:
                        positive_word_count, created = unsortedProductPositiveWordCount.objects.get_or_create(word=word)
                        if not created:
                            positive_word_count.count += 1
                            positive_word_count.save()
                    else:
                        negative_word_count, created = unsortedProductNegativeWordCount.objects.get_or_create(word=word)
                        if not created:
                            negative_word_count.count += 1
                            negative_word_count.save()

                # 更新地区统计模型
                location = sentence.content_location
                location_count, created = ProductLocationCount.objects.get_or_create(location=location)
                if not created:
                    location_count.count += 1
                    location_count.save()

    def __str__(self):
        return f"Word: {self.word}, Content ID: {self.content_id}, POS: {self.pos}, Positive: {self.is_positive}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2 Product_word'

class unsortedProductPositiveWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2.1 Unsorted Product Word Count'



class unsortedProductWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2.2 Unsorted Positive Word Count'


class unsortedProductNegativeWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Negative Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2.3 Unsorted Negative Word Count'


class ProductWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2.1 Product Word Count'



class ProductPositiveWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2.2 Product Positive Word Count'


class ProductNegativeWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词')
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Negative Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '2.2.3 Product Negative Word Count'


class ProductLocationCount(models.Model):
    location = models.CharField(max_length=100, verbose_name='地区')
    count = models.IntegerField(verbose_name='出现次数', default=1)

    def __str__(self):
        return f"Location: {self.location}, Count: {self.count}"

    class Meta:
        verbose_name_plural = verbose_name = '2.3 Product Location Count'




class Videosentence(models.Model):
    content = models.TextField(verbose_name='评论内容')
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    is_positive = models.BooleanField(verbose_name='好评', blank=True, null=True)
    content_time = models.DateField(verbose_name='评论时间', blank=True, null=True)
    upers = models.CharField(max_length=20, verbose_name='评论up主', blank=True, null=True)

    def save(self, *args, **kwargs):
        # 使用 SnowNLP 对评论内容进行情感分析并获取评分
        if self.content:
            s = SnowNLP(self.content)
            self.score = s.sentiments
            # 根据评分设置好评或差评的布尔值
            self.is_positive = True if self.score >= 0.5 else False
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Review ID: {self.pk}, Score: {self.score}, Positive: {self.is_positive}, Time: {self.content_time}"

    class Meta:
        verbose_name_plural = verbose_name = '3 Video_sentence'


class Videoword(models.Model):
        word = models.CharField(max_length=100, verbose_name='词')
        content_id = models.IntegerField(verbose_name='所属内容ID')
        content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)
        pos = models.CharField(max_length=10, verbose_name='词性')
        is_positive = models.BooleanField(verbose_name='好评')

        @classmethod
        def get_last_content_id(cls):
            last_object = cls.objects.last()
            if last_object:
                return last_object.content_id
                # print('1')
            else:
                # print('2')
                return 0

        @classmethod
        def create_words(cls, sentence):
            # 获取Videoword的最后一个对象的content_id
            last_content_id = cls.get_last_content_id()

            # 获取Videosentence的最后一个对象的pk
            last_sentence_pk = Videosentence.objects.last().pk

            # 比较最后一个content_id和最后一个sentence的pk
            if last_content_id < last_sentence_pk:
                # 获取新增的Videosentence对象
                new_sentences = Videosentence.objects.filter(pk__gt=last_content_id + 1)
                for sentence in new_sentences:
                    sentence.save()

                    # 加载停用词
                    stop_words = []
                    with open('D:\pythonProjectcatalogue\BS1\data-option\hit_stopwords.txt', 'r', encoding='utf-8') as file:
                        for line in file:
                            stop_words.append(line.strip())

                    # 获取标点符号集合
                    punctuation_set = set(string.punctuation)


                    # 使用jieba对句子进行分词和词性标注
                    words = jieba.cut_for_search(sentence.content)
                    for word in words:
                        # 排除标点符号和停用词
                        if word not in punctuation_set and word not in stop_words:
                            # 创建Videoword对象
                            videoword = cls.objects.create(
                                word=word,
                                content_id=sentence.pk,
                                content_uper=sentence.upers,
                                is_positive=sentence.is_positive
                            )
                        vedio_word,created = unsortedVideoWordCount.objects.get_or_create(
                                word=word
                            )
                        if not created:
                            vedio_word.count += 1
                            vedio_word.save()
                        # 根据is_positive更新对应的统计模型
                        if sentence.is_positive:
                            positive_word_count, created = unsortedvideoPositiveWordCount.objects.get_or_create(
                                word=word
                            )
                            if not created:
                                positive_word_count.count += 1
                                positive_word_count.save()
                        else:
                            negative_word_count, created = unsortedvideoNegativeWordCount.objects.get_or_create(
                                word=word
                            )
                            if not created:
                                negative_word_count.count += 1
                                negative_word_count.save()

                        # 根据content_uper更新对应的统计模型
                        if sentence.upers:

                            # 根据sentence.upers的值筛选对应的content_uper的数据
                            uper_word_data = unsortedUperVideoword.objects.filter(content_uper=sentence.upers)

                            # 检查词是否存在于对应的content_uper数据中
                            word_exist = uper_word_data.filter(word=word).exists()
                            if word_exist:
                                # 如果词已存在，则将计数加一
                                uper_word = uper_word_data.get(word=word)
                                uper_word.count += 1
                                uper_word.save()
                            else:
                                # 如果词不存在，则创建一个新的记录
                                unsortedUperVideoword.objects.create(
                                    word=word,
                                    count=1,
                                    content_uper=sentence.upers,
                                    score=SnowNLP(word).sentiments
                                )

                            if sentence.is_positive:
                                # 筛选UnsortedPosUperVideoword中与sentence.upers对应的数据
                                uper_word_data = UnsortedPosUperVideoword.objects.filter(content_uper=sentence.upers)
                            else:
                                # 筛选UnsortedNegUperVideoword中与sentence.upers对应的数据
                                uper_word_data = UnsortedNegUperVideoword.objects.filter(content_uper=sentence.upers)

                                # 检查词是否存在于对应的content_uper数据中
                            word_exist = uper_word_data.filter(word=word).exists()
                            if word_exist:
                                # 如果词已存在，则将计数加一
                                uper_word = uper_word_data.get(word=word)
                                uper_word.count += 1
                                uper_word.save()
                            else:
                                # 如果词不存在，则创建一个新的记录
                                UnsortedPosUperVideoword.objects.create(
                                    word=word,
                                    count=1,
                                    content_uper=sentence.upers,
                                    score=SnowNLP(word).sentiments if sentence.is_positive else None
                                ) if sentence.is_positive else UnsortedNegUperVideoword.objects.create(
                                    word=word,
                                    count=1,
                                    content_uper=sentence.upers,
                                    score=SnowNLP(word).sentiments if not sentence.is_positive else None
                                )

        def __str__(self):
            return f"Word: {self.word}, Content ID: {self.content_id}, POS: {self.pos}, Positive: {self.is_positive}"

        class Meta:
            verbose_name_plural = verbose_name = '3.1 Video_word'


class unsortedVideoWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.1.1 Unsorted Positive Word Count'


class VideoWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.1.1 Video Word Count'


class unsortedvideoPositiveWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.1.1 Unsorted Positive Word Count'


class unsortedvideoNegativeWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.1.2 Unsorted Negative Word Count'


class videoPositiveWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.1.1 Positive Word Count'


class videoNegativeWordCount(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.1.2 Negative Word Count'


class unsortedUperVideoword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.2.1 Unsorted Uper Word Count'


class UperVideoword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.2.1 Uper Word Count'


class UnsortedPosUperVideoword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.3.1 Unsorted Positive Uper Word Count'


class UnsortedNegUperVideoword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Positive Word: {self.word}, Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.3.2 Unsorted Negative Uper Word Count'


class PosUperVideoword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Word: {self.word}, Uper:{self.content_uper},Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.3.1 Positive Uper Word Count'


class NegUperVideoword(models.Model):
    word = models.CharField(max_length=100, verbose_name='词', blank=True)
    count = models.IntegerField(verbose_name='出现次数', default=1)
    score = models.FloatField(verbose_name='评分', blank=True, null=True)
    content_uper = models.CharField(verbose_name='所属内容Up主', max_length=20)

    def save(self, *args, **kwargs):
        if not self.score:
            s = SnowNLP(self.word)
            self.score = s.sentiments
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Word: {self.word}, Uper:{self.content_uper},Count: {self.count}, Score: {self.score}"

    class Meta:
        verbose_name_plural = verbose_name = '3.3.2 Negative Uper Word Count'





from collections import defaultdict
from appBS01.models import DateOccurrences

# class SortedDates:
#     @classmethod
#     def update_sorted_dates(cls):
#         # 读取评论时间数据并进行处理，更新数据库
#         date_counts = defaultdict(int)
#
#         # 读取所有时间数据并统计
#         with open('E:\\桌面文件\\杂\\评论数据\\all_time.txt', 'r', encoding='utf-8') as file:
#             comment_times_all = file.readlines()
#
#         # 提取日期并统计出现次数
#         for comment_time in comment_times_all:
#             date = comment_time.split()[1]
#             date_counts[date] += 1
#
#         # 按日期排序
#         sorted_dates_all = sorted(date_counts.items(), key=lambda x: x[0])
#
#         # 更新 DateOccurrences 对象
#         for date, count in sorted_dates_all:
#             obj, created = DateOccurrences.objects.get_or_create(date=date)
#             if not created:
#                 # 如果对象已存在，则累加出现次数
#                 obj.occurrences_all += count
#             else:
#                 obj.occurrences_all = count  # 如果是新创建的对象，则直接赋值出现次数
#             obj.save()
#
#         # 读取其他渠道的评论时间数据并统计
#             # 读取其他渠道的评论时间数据并统计
#             # 读取其他渠道的评论时间数据并统计
#             channels = ['jd', 'snyg', 'tb', 'wph']
#
#             # 遍历每个渠道
#         for channel in channels:
#             # 创建一个字典来存储每个日期的出现次数
#             date_counts_channel = defaultdict(int)
#
#             # 打开对应渠道的评论数据文件并读取
#             with open(f'E:\\桌面文件\\杂\\评论数据\\{channel}\\comments_data_creatime.txt', 'r',
#                         encoding='utf-8') as file:
#                 comment_times = file.readlines()
#
#             # 提取日期并统计出现次数
#             for comment_time in comment_times:
#                 date = comment_time.split()[1]
#                 date_counts_channel[date] += 1
#
#             # 遍历日期和出现次数，将评论数据存入数据库中对应的日期对象的对应渠道字段
#             for date, count in date_counts_channel.items():
#                 try:
#                     # 获取对应日期的对象
#                     obj = DateOccurrences.objects.get(date=date)
#                     print(obj.occurrences_all)
#                     # 更新对应渠道的出现次数字段
#                     field_name = f'occurrences_{channel.lower().replace(" ", "_")}'
#                     print(field_name)
#                     setattr(obj, field_name, count)
#                     print(obj.occurrences_jd)
#                     obj.save()
#                 except DateOccurrences.DoesNotExist:
#                     # 如果日期对象不存在，则跳过
#                     continue
