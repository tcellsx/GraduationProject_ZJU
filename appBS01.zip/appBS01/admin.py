### 不动 django提供的admin后台管理
from django.contrib import admin
# Register your models here.
###添加模型管理
from django.contrib import admin
from .models import Userinfo, DateOccurrences, Productsentence, Productword, ProductLocationCount, \
    unsortedProductPositiveWordCount, unsortedProductNegativeWordCount, ProductNegativeWordCount, \
    ProductPositiveWordCount, Videosentence, videoPositiveWordCount, unsortedvideoPositiveWordCount, \
    videoNegativeWordCount, unsortedvideoNegativeWordCount, Videoword, unsortedUperVideoword, UperVideoword, \
    NegUperVideoword, UnsortedNegUperVideoword, \
    UnsortedPosUperVideoword, PosUperVideoword, VideoWordCount, unsortedVideoWordCount, ProductWordCount, \
    unsortedProductWordCount, FrontendUser, ActivationCode
import jieba.posseg as pseg
from collections import defaultdict

### Register models
# admin.site.register(Userinfo)
admin.site.register(FrontendUser)
admin.site.register(DateOccurrences)
# admin.site.register(Productsentence)
admin.site.register(Productword)
admin.site.register(ProductNegativeWordCount)
admin.site.register(ProductPositiveWordCount)
# admin.site.register(unsortedProductPositiveWordCount)
# admin.site.register(unsortedProductNegativeWordCount)
admin.site.register(ProductLocationCount)

# admin.site.register(Videoword)
# admin.site.register(videoPositiveWordCount)
# admin.site.register(videoNegativeWordCount)
# admin.site.register(unsortedUperVideoword)
# admin.site.register(UperVideoword)
# admin.site.register(UnsortedNegUperVideoword)
# admin.site.register(NegUperVideoword)
# admin.site.register(UnsortedPosUperVideoword)
# admin.site.register(PosUperVideoword)

# admin.py
from django.contrib import admin
from .models import ActivationCode

class ActivationCodeAdmin(admin.ModelAdmin):
    actions = ['delete_zero_counts_and_add_new_code']

    def delete_zero_counts_and_add_new_code(self, request, queryset):
        for obj in queryset:
            obj.delete_zero_counts_and_add_new_code()
        self.message_user(request, "Deleted zero counts and added new activation code.")
    delete_zero_counts_and_add_new_code.short_description = "Delete Zero Counts & Add New Activation Code"

admin.site.register(ActivationCode, ActivationCodeAdmin)



###Generate words for selected sentences
class ProductsentenceAdmin(admin.ModelAdmin):
    actions = ['generate_words', 'sort_and_create_date_occurrences']  # 添加 sort_and_create_date_occurrences 到 actions 中

    def generate_words(self, request, queryset):
        for sentence in queryset:
            # Generate words for the selected sentence
            Productword.create_words(sentence)
            ProductWordCount.objects.all().delete()

            # Sort unsorted negative words by count
            sorted_positive_words = unsortedProductWordCount.objects.order_by('-count')

            # Transfer sorted data to ProductNegativeWordCount
            for word_obj in sorted_positive_words:
                ProductWordCount.objects.create(
                    word=word_obj.word,
                    count=word_obj.count,
                    score=word_obj.score
                )

            # Clear existing sorted data
            ProductPositiveWordCount.objects.all().delete()

            # Sort unsorted positive words by count
            sorted_positive_words = unsortedProductPositiveWordCount.objects.order_by('-count')

            # Transfer sorted data to ProductPositiveWordCount
            for word_obj in sorted_positive_words:
                ProductPositiveWordCount.objects.create(
                    word=word_obj.word,
                    count=word_obj.count,
                    score=word_obj.score
                )

            # Clear existing sorted data
            ProductNegativeWordCount.objects.all().delete()

            # Sort unsorted negative words by count
            sorted_negative_words = unsortedProductNegativeWordCount.objects.order_by('-count')

            # Transfer sorted data to ProductNegativeWordCount
            for word_obj in sorted_negative_words:
                ProductNegativeWordCount.objects.create(
                    word=word_obj.word,
                    count=word_obj.count,
                    score=word_obj.score
                )



        self.message_user(request, "Words have been generated for selected sentences.")

    generate_words.short_description = "Generate words for selected sentences"

    def sort_and_create_date_occurrences(self, request, queryset):
        # 删除原有的 DateOccurrences 表中的数据
        DateOccurrences.objects.all().delete()

        # 从 Productsentence 中获取数据，按日期和渠道进行分组和统计
        unsorted_data = Productsentence.objects.all().order_by('content_time', 'channel')

        sorted_data = {}
        for data in unsorted_data:
            date = data.content_time
            channel = data.channel

            # 检查日期是否已存在，若不存在则创建
            if date not in sorted_data:
                sorted_data[date] = {'jd': 0, 'wph': 0, 'tb': 0, 'snyg': 0}

            # 根据渠道更新数据
            if channel == 'jd':
                sorted_data[date]['jd'] += 1
            elif channel == 'wph':
                sorted_data[date]['wph'] += 1
            elif channel == 'tb':
                sorted_data[date]['tb'] += 1
            elif channel == 'snyg':
                sorted_data[date]['snyg'] += 1

        # 创建新的 DateOccurrences 表
        for date, occurrences in sorted_data.items():
            DateOccurrences.objects.create(
                date=date,
                occurrences_jd=occurrences['jd'],
                occurrences_wph=occurrences['wph'],
                occurrences_tb=occurrences['tb'],
                occurrences_snyg=occurrences['snyg'],
                occurrences_all=sum(occurrences.values())
            )

        self.message_user(request, "DateOccurrences has been sorted and created.")

    sort_and_create_date_occurrences.short_description = "Sort and create DateOccurrences"

admin.site.register(Productsentence, ProductsentenceAdmin)

# # Define admin actions for sorting and transferring data
# def sort_and_transfer_positive_words(modeladmin, request, queryset):
#     # Clear existing sorted data
#     ProductPositiveWordCount.objects.all().delete()
#
#     # Sort unsorted positive words by count
#     sorted_positive_words = unsortedProductPositiveWordCount.objects.order_by('-count')
#
#     # Transfer sorted data to ProductPositiveWordCount
#     for word_obj in sorted_positive_words:
#         ProductPositiveWordCount.objects.create(
#             word=word_obj.word,
#             count=word_obj.count,
#             score=word_obj.score
#         )
#
# sort_and_transfer_positive_words.short_description = "Sort and transfer positive words"
#
# def sort_and_transfer_negative_words(modeladmin, request, queryset):
#     # Clear existing sorted data
#     ProductNegativeWordCount.objects.all().delete()
#
#     # Sort unsorted negative words by count
#     sorted_negative_words = unsortedProductNegativeWordCount.objects.order_by('-count')
#
#     # Transfer sorted data to ProductNegativeWordCount
#     for word_obj in sorted_negative_words:
#         ProductNegativeWordCount.objects.create(
#             word=word_obj.word,
#             count=word_obj.count,
#             score=word_obj.score
#         )
#
# sort_and_transfer_negative_words.short_description = "Sort and transfer negative words"

# Register custom admin actions
# @admin.register(unsortedProductPositiveWordCount)
# class UnsortedProductPositiveWordCountAdmin(admin.ModelAdmin):
#     actions = [sort_and_transfer_positive_words]
#
# @admin.register(unsortedProductNegativeWordCount)
# class UnsortedProductNegativeWordCountAdmin(admin.ModelAdmin):
#     actions = [sort_and_transfer_negative_words]



class VediosentenceAdmin(admin.ModelAdmin):
    actions = ['generate_words']  # 添加 sort_and_create_date_occurrences 到 actions 中

    def generate_words(self, request, queryset):
        for sentence in queryset:
            # Generate words for the selected sentence
            Videoword.create_words(sentence)
            print('q')

        VideoWordCount.objects.all().delete()

        # Sort unsorted negative words by count
        sorted_positive_words = unsortedVideoWordCount.objects.order_by('-count')

        # Transfer sorted data to ProductNegativeWordCount
        for word_obj in sorted_positive_words:
            VideoWordCount.objects.create(
                word=word_obj.word,
                count=word_obj.count,
                score=word_obj.score
            )
        print('2')


        videoPositiveWordCount.objects.all().delete()

        # Sort unsorted negative words by count
        sorted_positive_words = unsortedvideoPositiveWordCount.objects.order_by('-count')

        # Transfer sorted data to ProductNegativeWordCount
        for word_obj in sorted_positive_words:
            videoPositiveWordCount.objects.create(
                word=word_obj.word,
                count=word_obj.count,
                score=word_obj.score
            )
        print('2')


        videoNegativeWordCount.objects.all().delete()

        # Sort unsorted negative words by count
        sorted_negative_words = unsortedvideoNegativeWordCount.objects.order_by('-count')

        # Transfer sorted data to ProductNegativeWordCount
        for word_obj in sorted_negative_words:
            videoNegativeWordCount.objects.create(
                word=word_obj.word,
                count=word_obj.count,
                score=word_obj.score
            )
        print('3')



        # 删除现有的 UperVideoword 对象
        UperVideoword.objects.all().delete()

        # 使用 content_uper 对未排序的词进行分类的字典
        unsorted_words_by_uper = defaultdict(list)

        # 按 content_uper 和 count 对未排序的词进行排序
        unsorted_words = unsortedUperVideoword.objects.all()
        for word_obj in unsorted_words:
            unsorted_words_by_uper[word_obj.content_uper].append(word_obj)

        # 将排序后的数据转移到 UperVideoword
        for uper, words in unsorted_words_by_uper.items():
            sorted_words = sorted(words, key=lambda x: x.count, reverse=True)
            for word_obj in sorted_words:
                UperVideoword.objects.create(
                    word=word_obj.word,
                    count=word_obj.count,
                    score=word_obj.score,
                    content_uper=word_obj.content_uper
                )
        print('nb')

        # 删除现有的 UperVideoword 对象
        PosUperVideoword.objects.all().delete()

        # 使用 content_uper 对未排序的词进行分类的字典
        unsorted_words_by_uper = defaultdict(list)

        # 按 content_uper 和 count 对未排序的词进行排序
        unsorted_words = UnsortedPosUperVideoword.objects.all()
        for word_obj in unsorted_words:
            unsorted_words_by_uper[word_obj.content_uper].append(word_obj)

        # 将排序后的数据转移到 UperVideoword
        for uper, words in unsorted_words_by_uper.items():
            sorted_words = sorted(words, key=lambda x: x.count, reverse=True)
            for word_obj in sorted_words:
                PosUperVideoword.objects.create(
                    word=word_obj.word,
                    count=word_obj.count,
                    score=word_obj.score,
                    content_uper=word_obj.content_uper
                )
        print('nb')

        # 删除现有的 UperVideoword 对象
        NegUperVideoword.objects.all().delete()

        # 使用 content_uper 对未排序的词进行分类的字典
        unsorted_words_by_uper = defaultdict(list)

        # 按 content_uper 和 count 对未排序的词进行排序
        unsorted_words = UnsortedNegUperVideoword.objects.all()
        for word_obj in unsorted_words:
            unsorted_words_by_uper[word_obj.content_uper].append(word_obj)

        # 将排序后的数据转移到 UperVideoword
        for uper, words in unsorted_words_by_uper.items():
            sorted_words = sorted(words, key=lambda x: x.count, reverse=True)
            for word_obj in sorted_words:
                NegUperVideoword.objects.create(
                    word=word_obj.word,
                    count=word_obj.count,
                    score=word_obj.score,
                    content_uper=word_obj.content_uper
                )
        print('nb')






        self.message_user(request, "Words have been generated for selected sentences.")

    generate_words.short_description = "Generate words for selected sentences"

admin.site.register(Videosentence, VediosentenceAdmin)


### 搜索框
class ProductWordCountAdmin(admin.ModelAdmin):
    search_fields = ['word']

class VideowordAdmin(admin.ModelAdmin):
    search_fields = ['word']

class VideoWordCountAdmin(admin.ModelAdmin):
    search_fields = ['word']

class VideoPositiveWordCountAdmin(admin.ModelAdmin):
    search_fields = ['word']

class VideoNegativeWordCountAdmin(admin.ModelAdmin):
    search_fields = ['word']

class UperVideowordAdmin(admin.ModelAdmin):
    search_fields = ['word','content_uper']

class NegUperVideowordAdmin(admin.ModelAdmin):
    search_fields = ['word','content_uper']

class PosUperVideowordAdmin(admin.ModelAdmin):
    search_fields = ['word','content_uper']


admin.site.register(ProductWordCount, ProductWordCountAdmin)
admin.site.register(Videoword, VideowordAdmin)
admin.site.register(VideoWordCount, VideoWordCountAdmin)
admin.site.register(videoPositiveWordCount, VideoPositiveWordCountAdmin)
admin.site.register(videoNegativeWordCount, VideoNegativeWordCountAdmin)
admin.site.register(UperVideoword, UperVideowordAdmin)
admin.site.register(NegUperVideoword, NegUperVideowordAdmin)
admin.site.register(PosUperVideoword, PosUperVideowordAdmin)





# from django.contrib import admin
# from .models import Userinfo, DateOccurrences, Productword, ProductPositiveWordCount, ProductNegativeWordCount, ProductLocationCount, Productsentence
# from django.db.models import F
#
# ###Generate words for selected sentences
# class ProductsentenceAdmin(admin.ModelAdmin):
#     actions = ['generate_words']
#
#     def generate_words(self, request, queryset):
#         for sentence in queryset:
#             # Assuming create_words() is defined in the Productword model
#             Productword.create_words()
#     generate_words.short_description = "Generate words for selected sentences"
#
# @admin.register(ProductPositiveWordCount)
# class ProductPositiveWordCountAdmin(admin.ModelAdmin):
#     list_display = ['word', 'count', 'score']
#     actions = ['sort_by_count']
#
#     def sort_by_count(self, request, queryset):
#         # Perform sorting directly on the database
#         queryset = queryset.order_by('-count')
#         count = 1
#         for item in queryset:
#             item.count = count
#             item.save(update_fields=['count'])
#             count += 1
#         self.message_user(request, "Sorted by count.")
#     sort_by_count.short_description = "Sort by count"
#
# @admin.register(ProductNegativeWordCount)
# class ProductNegativeWordCountAdmin(admin.ModelAdmin):
#     list_display = ['word', 'count', 'score']
#     actions = ['sort_by_count']
#
#     def sort_by_count(self, request, queryset):
#         # Perform sorting directly on the database
#         queryset = queryset.order_by('-count')
#         count = 1
#         for item in queryset:
#             item.count = count
#             item.save(update_fields=['count'])
#             count += 1
#         self.message_user(request, "Sorted by count.")
#     sort_by_count.short_description = "Sort by count"
#
# admin.site.register(Userinfo)
# admin.site.register(DateOccurrences)
# admin.site.register(Productword)
# admin.site.register(ProductLocationCount)
# admin.site.register(Productsentence, ProductsentenceAdmin)





